tinyMCE.addI18n('cs.codemagic',{
    code_title: "CodeMagic - zvýraznení syntaxe a formátování kódu",
    code_label: "Editovat kód",
    toggle_highlighting: "Zvýraznení kódu",
    toggle_autocompletion: "Doplňování kódu",
    search: "Hledat",
    replace: "Nahradit",
    undo: "Zpět",
    redo: "Opakovat",
    search_replace: "Hledat a nahradit",
    reintendt: "Zformátovat kód",
    nothing_found: "Hledaný výraz nebyl nalezen.",
    nothing_to_replace: "Není co nahradit."
});
